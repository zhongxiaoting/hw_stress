#include <stdlib.h>
#include <stdio.h>

extern void f1();

void use_s1(void)
{
//      printf("calling function f1");
	f1();
}
