#include <stdio.h>
void file2(void)
{
	printf("Control in function %s\n", __func__);
}
