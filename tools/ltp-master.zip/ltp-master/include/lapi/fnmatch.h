// SPDX-License-Identifier: GPL-2.0-or-later
/*
 * Copyright (c) 2018 Linaro Limited. All rights reserved.
 * Author: Rafael David Tinoco <rafael.tinoco@linaro.org>
 */

#ifndef LAPI_FNMATCH_H__
#define LAPI_FNMATCH_H__

#ifndef FNM_EXTMATCH
#define FNM_EXTMATCH 0
#endif

#endif /* LAPI_FNMATCH_H__ */
