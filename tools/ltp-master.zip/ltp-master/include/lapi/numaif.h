// SPDX-License-Identifier: GPL-2.0-or-later
/*
 * Copyright (c) 2021 Linux Test Project
 */

#ifndef LAPI_NUMAIF_H__
#define LAPI_NUMAIF_H__

#ifndef MPOL_LOCAL
# define MPOL_LOCAL	4
#endif

#endif /* LAPI_NUMAIF_H__ */
