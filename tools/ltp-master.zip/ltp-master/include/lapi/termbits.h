// SPDX-License-Identifier: GPL-2.0-or-later
/*
 * Copyright (c) 2018 Linux Test Project
 */

#ifndef LAPI_TERMBITS_H__
#define LAPI_TERMBITS_H__

#ifndef EXTPROC
# define EXTPROC     0200000
#endif

#endif /* LAPI_TERMBITS_H__ */
