#include "include.h"

static struct tst_test test = {
	.test_variants = ARRAY_SIZE(variants),
};
