#define SYSCALL		"syscall(\"foo\")"

static struct tst_test test = {
	.syscall = SYSCALL,
};
