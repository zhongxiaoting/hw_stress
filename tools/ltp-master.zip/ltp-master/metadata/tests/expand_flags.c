static struct tst_test test = {
	.all_filesystems = 1,
};
