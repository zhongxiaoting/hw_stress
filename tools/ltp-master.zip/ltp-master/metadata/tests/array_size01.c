static int variants[] = {1};

static struct tst_test test = {
	.test_variants = ARRAY_SIZE(variants),
};
